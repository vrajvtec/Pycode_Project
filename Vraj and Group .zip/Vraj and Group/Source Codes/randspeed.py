import random
import matplotlib.pyplot as plt 
import numpy as np
import time
import gtts
from backend import *
from gtts import gTTS
from playsound  import playsound 
def speedModule():
    
    # def warning120(myText):
    #     #audio120=gTTS(myText)
    #     #audio120.save('warning120.mp3')
    # #warning120('overspeeding')  



    speedList=[]
    timee=range(20)
    for i in range(20):
        n=random.randint(0,150)
        #print(n)
        if n>120:
           
            print('')
            print(f'The current speed = {n} Km/hr')
            print('over speeding')
            print('')
            #playsound('warning120.mp3')        
            
        elif n>130:
            time.sleep(2)
            print('reduce speed')
            print('')
            print(f'The current speed = {n} Km/hr')
            #playsound('warning120.mp3')     
            print('')
            

        elif n>80:
            time.sleep(2)
            playsound('alert.mp3') 
            print('')
            print(f'The current speed = {n} Km/hr')
            print('')
            
            
        else:
            time.sleep(2)
            #print('Drive Safe')
            print('')
            print(f'The current speed = {n} Km/hr')
            print('')
            

        speedList.append(n)
        speedList.sort()

    deceleration=[]
    timee=range(20)
    for i in range(20):
        d=random.randint(0,150)
        deceleration.append(d)
        deceleration.sort()
        deceleration=deceleration[::-1]
    #print(deceleration)




    time.sleep(10)



    plt.title('Instantaneous Acceleration')
    plt.plot(timee,speedList,color='green',linestyle='--',label='Acceleration')
    plt.plot(timee,deceleration,color='red',linestyle='--',label='Deceleration')
    plt.legend()

    fig,(ax1,ax2)=plt.subplots(2,1)
    fig.suptitle('Acceleration and Decelartion (SpeedVariations)')
    ax1.plot(timee,speedList)
    ax2.plot(timee,deceleration,color='red')
    ax1.set_ylabel('Instaneous Speed(km/hr)')
    ax2.set_ylabel('Instaneous Speed(km/hr)')

    ax1.set_xlabel('Time Interval')
    ax2.set_xlabel(' TIme Interval ')

    plt.show()
#speedModule()